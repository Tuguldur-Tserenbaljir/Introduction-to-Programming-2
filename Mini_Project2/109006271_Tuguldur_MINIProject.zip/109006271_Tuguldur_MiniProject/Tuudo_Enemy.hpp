#ifndef TUUDO_ENEMY_HPP
#define TUUDO_ENEMY_HPP
#include "Enemy.hpp"

class Tuudo_Enemy : public Enemy {
public:
	Tuudo_Enemy(int x, int y);
	void CreateBullet() override;
};
#endif // Tuudo_enemy_HPP
