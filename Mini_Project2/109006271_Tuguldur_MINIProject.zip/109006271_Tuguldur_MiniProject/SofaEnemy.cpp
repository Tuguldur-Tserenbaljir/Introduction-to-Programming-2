#include <string>

#include "SofaEnemy.hpp"
#include "CoachEnemyBullet.hpp"
SofaEnemy::SofaEnemy(int x, int y) : Enemy("play/enemy-2.png", x, y, 10, 1, 50, 5, 5) {
	// Use bounding circle to detect collision is for simplicity, pixel-perfect collision can be implemented quite easily,
	// and efficiently if we use AABB collision detection first, and then pixel-perfect collision.
}
void SofaEnemy::CreateBullet() {
	Engine::Point diff = Engine::Point(1, 0);
	float rotation = ALLEGRO_PI / 2;
	getPlayScene()->BulletGroup->AddNewObject(new CoachEnemyBullet(Position, diff, rotation, this));
	AudioHelper::PlayAudio("gun.wav");
}
