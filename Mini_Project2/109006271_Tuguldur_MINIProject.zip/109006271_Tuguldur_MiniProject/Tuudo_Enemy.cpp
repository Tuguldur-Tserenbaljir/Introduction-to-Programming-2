#include <string>

#include "Tuudo_Enemy.hpp"
#include "Tuudo_EnemyBullet.hpp"
Tuudo_Enemy::Tuudo_Enemy(int x, int y) : Enemy("play/enemy-4.png", x, y, 22,1, 100, 15, 15) {
    // TODO 2 (6/8): You can imitate the 2 files: 'NormalEnemy.hpp', 'NormalEnemy.cpp' to create a new enemy.
}
void Tuudo_Enemy::CreateBullet() {
	Engine::Point diff = Engine::Point(1, 0);
	float rotation = ALLEGRO_PI / 2;
	getPlayScene()->BulletGroup->AddNewObject(new Tuudo_EnemyBullet(Position, diff, rotation, this));
	AudioHelper::PlayAudio("gun.wav");
}
