#ifndef TUUDO_TURRET3_HPP
#define TUUDO_TURRET3_HPP
#include "Turret.hpp"

class Tuudo_Turret3 : public Turret {
public:
	static int hp;
	static const int Price;
	Tuudo_Turret3(float x, float y);
	void CreateBullet() override;
};
#endif // Tuudo_Turret2.HPP