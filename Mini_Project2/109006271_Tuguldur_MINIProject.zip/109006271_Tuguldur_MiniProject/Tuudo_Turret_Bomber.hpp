#ifndef TUUDO_TURRET_BOMBER_HPP
#define TUUDO_TURRET_BOMBER_HPP
#include "Turret.hpp"

class Tuudo_Turret_Bomber : public Turret {
public:
	static int hp;
	static const int Price;
	Tuudo_Turret_Bomber(float x, float y);
	void CreateBullet() override;
};
#endif // Tuudo_Turret.HPP