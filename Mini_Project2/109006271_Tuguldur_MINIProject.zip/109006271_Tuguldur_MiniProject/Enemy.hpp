#ifndef ENEMY_HPP
#define ENEMY_HPP
#include <list>
#include <vector>
#include <string>

#include "Point.hpp"
#include "Sprite.hpp"
#include "Enemy.hpp"
#include "GameEngine.hpp"
#include "Group.hpp"
#include "IObject.hpp"
#include "IScene.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Turret.hpp"
#include "ExplosionEffect.hpp"
#include "AudioHelper.hpp"
#include "Bullet.hpp"
#include "DirtyEffect.hpp"


class Bullet;
class PlayScene;
class Turret;

class Enemy : public Engine::Sprite {
protected:
	Engine::Point target;
	float speed;
	float hp;
	int money;
	PlayScene* getPlayScene();
	virtual void OnExplode();
	virtual void CreateBullet()=0;
	float coolDown;
	float reload = 0;
public:
	float reachEndTime;
	std::list<Turret*> lockedTurrets;

	std::list<Turret*>::iterator lockedEnemyIterator;
	std::list<Bullet*> lockedBullets;
	Enemy(std::string img, float x, float y, float radius, float cooldown, float speed, float hp, int money );
 	void Hit(float damage);
	void Update(float deltaTime) override;
	void Draw() const override;
	void Attack(float damage);
	Turret* Target = nullptr;

};
#endif // ENEMY_HPP
