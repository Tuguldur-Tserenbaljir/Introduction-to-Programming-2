#ifndef TUUDO_TURRET2_HPP
#define TUUDO_TURRET2_HPP
#include "Turret.hpp"

class Tuudo_Turret2 : public Turret {
public:
	static int hp;
	static const int Price;
	Tuudo_Turret2(float x, float y);
	void CreateBullet() override;
};
#endif // Tuudo_Turret2.HPP