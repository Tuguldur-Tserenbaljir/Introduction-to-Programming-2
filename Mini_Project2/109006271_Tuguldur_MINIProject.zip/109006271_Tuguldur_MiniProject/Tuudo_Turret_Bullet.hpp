#ifndef Tuudo_Turret_Bullet_HPP
#define Tuudo_Turret_Bullet_HPP
#include "Bullet.hpp"

class Enemy;
class Turret;
namespace Engine {
	struct Point;
}  // namespace Engine

class Tuudo_Turret_Bullet : public Bullet {
public:
	explicit Tuudo_Turret_Bullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Turret* parent);
	void OnExplode(Enemy* enemy) override;
};
#endif // ICECREAMBULLET_HPP
