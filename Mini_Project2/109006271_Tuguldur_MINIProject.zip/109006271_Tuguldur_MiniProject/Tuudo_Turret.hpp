#ifndef TUUDO_TURRET_HPP
#define TUUDO_TURRET_HPP
#include "Turret.hpp"

class Tuudo_Turret : public Turret {
public:
	static int hp;
	static const int Price;
	Tuudo_Turret(float x, float y);
	void CreateBullet() override;
};
#endif // Tuudo_Turret.HPP