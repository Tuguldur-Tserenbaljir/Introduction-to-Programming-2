#ifndef TUUDO_ENEMYBULLET_HPP
#define TUUDO_ENEMYBULLET_HPP
#include "EnemyBullet.hpp"

class Enemy;
class Turret;
namespace Engine {
	struct Point;
}  // namespace Engine

class Tuudo_EnemyBullet : public EnemyBullet {
public:
	explicit Tuudo_EnemyBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Enemy* parent);
	void OnExplode(Turret* turret) override;
};
#endif // ICECREAMBULLET_HPP
