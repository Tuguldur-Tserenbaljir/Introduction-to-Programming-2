#ifndef COACHENEMYBULLET_HPP
#define COACHENEMYBULLET_HPP
#include "EnemyBullet.hpp"

class Enemy;
class Turret;
namespace Engine {
	struct Point;
}  // namespace Engine

class CoachEnemyBullet : public EnemyBullet {
public:
	explicit CoachEnemyBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Enemy* parent);
	void OnExplode(Turret* turret) override;
};
#endif // ICECREAMBULLET_HPP
