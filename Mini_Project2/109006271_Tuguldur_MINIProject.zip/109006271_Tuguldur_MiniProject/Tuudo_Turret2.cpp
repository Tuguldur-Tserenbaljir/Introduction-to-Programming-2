#include <allegro5/base.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
#include "Tuudo_Turret2_Bullet.hpp"
#include "Group.hpp"
#include "Tuudo_Turret2.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Enemy.hpp"
const int Tuudo_Turret2::Price = 10;
int Tuudo_Turret2::hp = 100;
Tuudo_Turret2::Tuudo_Turret2(float x, float y) :
	// TODO 2 (2/8): You can imitate the 2 files: 'FreezeTurret.hpp', 'FreezeTurret.cpp' to create a new turret.
	Turret("play/turret-4.png", x, y, 30, Price, 0.5, hp,3) {
	// Move center downward, since we the turret head is slightly biased upward.
	Anchor.y += 8.0f / GetBitmapHeight();
}
void Tuudo_Turret2::CreateBullet() {
	//Engine::Point diff = Engine::Point(1, 0);
	//float rotation = ALLEGRO_PI / 2;
	//getPlayScene()->BulletGroup->AddNewObject(new Tuudo_Turret2_Bullet(Position, diff, rotation, this));
	//AudioHelper::PlayAudio("gun.wav");
}
